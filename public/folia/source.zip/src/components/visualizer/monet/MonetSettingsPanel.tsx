import React, { useRef, useState } from 'react';
import { ImagePlus, Trash2 } from 'lucide-react';
import { useVisualizerAssetStore } from '../../../stores/useVisualizerAssetStore';
import { DEFAULT_MONET_TUNING, type MonetAudioStyle, type MonetChromeVisibility, type MonetPortraitSource, type MonetTuning } from '../../../types';
import { DEFAULT_LYRIC_RENDER_OVERRIDE } from '../../../utils/lyricRenderQuality';
import { Button, Group, PictureGrid, Reveal, Row, Segmented, TextField, type SettingsGroupDef } from '../../modal/settings/kit';
import { type VisualizerSettingsPanelProps } from '../definition';
import { SliderRow, times, ToggleRow } from '../panelRows';
import LyricRenderQualityRows from '../renderQuality/LyricRenderQualityRows';
import { MONET_CUSTOM_DESCRIPTION_MAX_LENGTH, resolveMonetChromeVisibility } from './tuning';

// src/components/visualizer/monet/MonetSettingsPanel.tsx
// Monet-specific lyric, audio, portrait and render controls, as four groups of the settings kit.
// Background controls live in the shared background panel.
const LYRICS_GROUP: SettingsGroupDef = { id: 'vis-monet-lyrics', titleKey: 'options.lyricsStyleSettings' };
const PORTRAIT_GROUP: SettingsGroupDef = { id: 'vis-monet-portrait', titleKey: 'options.cappellaAvatarSource' };
const AUDIO_GROUP: SettingsGroupDef = { id: 'vis-monet-audio', titleKey: 'options.monetAudioStyle' };
// 只有底部音频条是 canvas 2D：只给分辨率一行（#929）。
const RENDER_GROUP: SettingsGroupDef = { id: 'vis-monet-render', titleKey: 'options.lyricRenderSection' };

type MonetPortraitStyle = 'rectangular' | 'square';

const clampValue = (value: number, min: number, max: number, fallback: number) => (
    Number.isFinite(value)
        ? Math.min(max, Math.max(min, value))
        : fallback
);

/** The portrait's frame: tall, or square. */
const portraitStylePicture = (style: MonetPortraitStyle) => (
    <span className="absolute inset-0 grid place-items-center">
        <span className={`rounded-sm bg-[var(--st-t2)] ${style === 'square' ? 'aspect-square h-[56%]' : 'aspect-[3/4] h-[76%]'}`} />
    </span>
);

/** The spectrum at the bottom: bars, or one line. */
const audioStylePicture = (style: MonetAudioStyle) => (
    <svg viewBox="0 0 64 40" className="absolute inset-0 h-full w-full text-[color:var(--st-t2)]" fill="none" stroke="currentColor" strokeLinecap="round">
        {style === 'bar' ? (
            <path strokeWidth="3" d="M14 30V22M22 30V14M30 30V19M38 30V10M46 30V17M54 30V24" />
        ) : (
            <path strokeWidth="2" strokeLinejoin="round" d="M10 26L18 21L26 24L34 12L42 19L50 15L56 23" />
        )}
    </svg>
);

export const MonetSettingsPanel: React.FC<VisualizerSettingsPanelProps<MonetTuning>> = ({
    t,
    tuning: monetTuning = DEFAULT_MONET_TUNING,
    onTuningChange: onMonetTuningChange,
    settings: {
        handleUploadMonetPortraitImage: onUploadMonetPortraitImage,
        handleClearMonetPortraitImage: onClearMonetPortraitImage,
    },
    onSliderPointerDown,
    onSliderCommit,
}) => {
    // The listener's own portrait and whether it is still being read back: the style's own, so the panel takes them itself.
    const monetPortraitImage = useVisualizerAssetStore(state => state.monetPortraitImage);
    const isLoadingMonetPortraitImage = useVisualizerAssetStore(state => state.isLoadingMonetPortraitImage);
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const [feedback, setFeedback] = useState<string | null>(null);
    const resolvedTuning = {
        keywordColoringEnabled: monetTuning.keywordColoringEnabled ?? DEFAULT_MONET_TUNING.keywordColoringEnabled,
        showDescription: monetTuning.showDescription ?? DEFAULT_MONET_TUNING.showDescription,
        showAudioVisualization: monetTuning.showAudioVisualization ?? DEFAULT_MONET_TUNING.showAudioVisualization,
        audioStyle: monetTuning.audioStyle ?? DEFAULT_MONET_TUNING.audioStyle,
        fontScale: clampValue(monetTuning.fontScale ?? DEFAULT_MONET_TUNING.fontScale, 0.7, 1.5, DEFAULT_MONET_TUNING.fontScale),
        portraitSource: monetTuning.portraitSource ?? DEFAULT_MONET_TUNING.portraitSource,
        portraitStyle: monetTuning.portraitStyle ?? DEFAULT_MONET_TUNING.portraitStyle ?? 'rectangular',
        showPortraitDragHanger: monetTuning.showPortraitDragHanger ?? DEFAULT_MONET_TUNING.showPortraitDragHanger,
        descriptionVisibility: resolveMonetChromeVisibility(monetTuning.descriptionVisibility, monetTuning.showDescription),
        portraitHangerVisibility: resolveMonetChromeVisibility(monetTuning.portraitHangerVisibility, monetTuning.showPortraitDragHanger),
        mirrorLayout: monetTuning.mirrorLayout ?? false,
        customDescription: monetTuning.customDescription ?? '',
    };
    const showsPortrait = resolvedTuning.portraitSource !== 'none';
    const visibilityOptions: Array<{ value: MonetChromeVisibility; label: string }> = [
        { value: 'auto', label: t('options.monetChromeVisibilityAuto') },
        { value: 'always', label: t('options.monetChromeVisibilityAlways') },
        { value: 'hidden', label: t('options.monetChromeVisibilityHidden') },
    ];

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(event.target.files ?? []);
        event.target.value = '';
        setFeedback(null);
        if (!files.length || !onUploadMonetPortraitImage) {
            return;
        }

        const result = await onUploadMonetPortraitImage(files);
        if (result.ok) {
            onMonetTuningChange?.({ portraitSource: 'custom' });
            setFeedback(files[0].name);
        } else {
            setFeedback(result.error || t('options.monetUploadPortrait'));
        }
    };

    return (
        <>
            <Group def={LYRICS_GROUP}>
                <SliderRow
                    label={t('options.monetFontScale')}
                    value={resolvedTuning.fontScale}
                    min={0.7}
                    max={1.5}
                    step={0.05}
                    format={times}
                    onChange={(value) => onMonetTuningChange?.({ fontScale: value })}
                    onDragStart={onSliderPointerDown}
                    onDragEnd={onSliderCommit}
                />
                <ToggleRow
                    label={t('options.monetMirrorLayout')}
                    checked={resolvedTuning.mirrorLayout}
                    onChange={(value) => onMonetTuningChange({ mirrorLayout: value })}
                />
                <ToggleRow
                    label={t('options.monetKeywordColoring')}
                    checked={resolvedTuning.keywordColoringEnabled}
                    onChange={(value) => onMonetTuningChange?.({ keywordColoringEnabled: value })}
                />
                <Row label={t('options.monetShowDescription')}>
                    <Segmented<MonetChromeVisibility>
                        value={resolvedTuning.descriptionVisibility}
                        options={visibilityOptions}
                        onChange={(value) => onMonetTuningChange({ descriptionVisibility: value })}
                    />
                </Row>
                <Reveal when={resolvedTuning.descriptionVisibility !== 'hidden'}>
                    {/* The field gets a line of its own under the label: beside it, it wrapped under the label's hint. */}
                    <Row
                        sub
                        label={t('options.monetCustomDescription')}
                        below={(
                            <TextField
                                value={resolvedTuning.customDescription}
                                placeholder={t('options.monetCustomDescriptionPlaceholder')}
                                onChange={(value) => onMonetTuningChange({ customDescription: value.slice(0, MONET_CUSTOM_DESCRIPTION_MAX_LENGTH) })}
                            />
                        )}
                    />
                </Reveal>
            </Group>

            <Group def={PORTRAIT_GROUP}>
                <Row label={t(resolvedTuning.mirrorLayout ? 'options.monetPortraitSourceMirrored' : 'options.monetPortraitSource')}>
                    <Segmented<MonetPortraitSource>
                        value={resolvedTuning.portraitSource}
                        options={[
                            { value: 'cover', label: t('options.monetPortraitSourceCover') },
                            {
                                value: 'custom',
                                label: t('options.monetPortraitSourceCustom'),
                                disabled: !monetPortraitImage && !isLoadingMonetPortraitImage,
                            },
                            { value: 'none', label: t('options.monetPortraitSourceNone') },
                        ]}
                        onChange={(value) => onMonetTuningChange?.({ portraitSource: value })}
                    />
                </Row>
                <Row
                    label={t('options.monetUploadPortrait')}
                    hint={feedback || monetPortraitImage?.name || '-'}
                >
                    <Button
                        icon={ImagePlus}
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isLoadingMonetPortraitImage || !onUploadMonetPortraitImage}
                    >
                        {t('options.monetUploadPortrait')}
                    </Button>
                    <Button
                        icon={Trash2}
                        onClick={() => void onClearMonetPortraitImage?.()}
                        disabled={!monetPortraitImage || !onClearMonetPortraitImage}
                    >
                        {t('options.monetClearPortrait')}
                    </Button>
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept=".png,.jpg,.jpeg,.gif,.webp,.svg,image/*"
                        className="hidden"
                        onChange={(event) => void handleFileChange(event)}
                    />
                </Row>
                <Reveal when={showsPortrait}>
                    <Row
                        label={t('options.monetPortraitStyle')}
                        below={(
                            <PictureGrid<MonetPortraitStyle>
                                className="-mx-4"
                                columns={4}
                                label={t('options.monetPortraitStyle')}
                                value={resolvedTuning.portraitStyle}
                                options={[
                                    { value: 'rectangular', label: t('options.monetPortraitStyleRectangular') },
                                    { value: 'square', label: t('options.monetPortraitStyleSquare') },
                                ]}
                                picture={portraitStylePicture}
                                onChange={(value) => onMonetTuningChange?.({ portraitStyle: value })}
                            />
                        )}
                    />
                    <Row label={t('options.monetPortraitDragHanger')}>
                        <Segmented<MonetChromeVisibility>
                            value={resolvedTuning.portraitHangerVisibility}
                            options={visibilityOptions}
                            onChange={(value) => onMonetTuningChange({ portraitHangerVisibility: value })}
                        />
                    </Row>
                </Reveal>
            </Group>

            <Group def={AUDIO_GROUP}>
                <ToggleRow
                    label={t('options.monetShowAudioVisualization')}
                    checked={resolvedTuning.showAudioVisualization}
                    onChange={(value) => onMonetTuningChange?.({ showAudioVisualization: value })}
                />
                <Reveal when={resolvedTuning.showAudioVisualization}>
                    <Row
                        sub
                        label={t('options.monetAudioStyle')}
                        below={(
                            <PictureGrid<MonetAudioStyle>
                                className="-mx-4"
                                columns={4}
                                label={t('options.monetAudioStyle')}
                                value={resolvedTuning.audioStyle}
                                options={[
                                    { value: 'bar', label: t('options.monetAudioStyleBar') },
                                    { value: 'line', label: t('options.monetAudioStyleLine') },
                                ]}
                                picture={audioStylePicture}
                                onChange={(value) => onMonetTuningChange?.({ audioStyle: value })}
                            />
                        )}
                    />
                </Reveal>
            </Group>

            <Group def={RENDER_GROUP}>
                <LyricRenderQualityRows
                    value={monetTuning.render ?? DEFAULT_LYRIC_RENDER_OVERRIDE}
                    onChange={(patch) => onMonetTuningChange?.({ render: { ...(monetTuning.render ?? DEFAULT_LYRIC_RENDER_OVERRIDE), ...patch } })}
                    antialias={false}
                />
            </Group>
        </>
    );
};
