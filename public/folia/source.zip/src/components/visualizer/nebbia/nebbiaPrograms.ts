import { checkLinked, compileShader, startProgram } from './nebbiaGlUtils';
import { NEBBIA_MASK_FS, NEBBIA_MASK_VS } from './nebbiaMaskGl';
import { NEBBIA_BLD_FILL_FS, NEBBIA_NOISE_FS, NEBBIA_SPRITE_FS, NEBBIA_SPRITE_VS, NEBBIA_VS, nebbiaSceneShaders } from './nebbiaShaders';
import { NEBBIA_FLAKE_FS, NEBBIA_FLAKE_VS } from './nebbiaSnowGl';
import { NEBBIA_FIREFLY_FS, NEBBIA_FIREFLY_VS } from './nebbiaFireflyGl';
import type { NebbiaGlass, NebbiaWindowScene } from './types';

// src/components/visualizer/nebbia/nebbiaPrograms.ts
// 雾笺的着色器程序（雾的预渲染、主画面、水珠精灵、擦痕遮罩、楼群缓存的补画、静态噪声纹理、雪花、萤虫）在后台编：有 KHR_parallel_shader_compile 时提交了不等，
// 每帧问一次编好没有，编好才查链接结果（查结果会一直等到编完，D3D11 上冷编要将近 1 秒）；没有这个扩展就当场等。
// 运行时（nebbiaGl.ts）和启动时的预热（nebbiaShaderWarmup.ts）都从这里编：源码、属性位置一样，GPU 进程的程序缓存才对得上。
// 雾的预渲染和主画面按窗外场景编（街景或水族箱）；楼群缓存的补画只有街景要；雪花（nebbiaSnowGl.ts）只有雪窗要，玻璃上的萤虫（nebbiaFireflyGl.ts）只有凝露要。

export interface NebbiaPrograms {
    /** 雾的预渲染；不能渲染到浮点纹理时没有（主画面自己算雾）。 */
    fog: WebGLProgram | null;
    main: WebGLProgram;
    sprite: WebGLProgram;
    /** 擦痕遮罩（nebbiaMaskGl.ts）。 */
    mask: WebGLProgram;
    /** 往楼群缓存里补画（nebbiaBuildingCache.ts）；窗外是水族箱时没有。 */
    bldFill: WebGLProgram | null;
    /** 算静态噪声纹理（nebbiaNoiseTex.ts）。 */
    noise: WebGLProgram;
    /** 雪窗的雪花（nebbiaSnowGl.ts）；别的玻璃没有。 */
    flake: WebGLProgram | null;
    /** 凝露玻璃上的萤虫（nebbiaFireflyGl.ts）；别的玻璃没有。 */
    firefly: WebGLProgram | null;
}

type ParallelCompile = { COMPLETION_STATUS_KHR: number };

/** 能不能把雾预渲染到浮点纹理：有 EXT_color_buffer_float，而且 RGBA16F 的帧缓冲拼得起来。上下文刚建好时调（查状态要等 GPU 进程一个来回）。 */
export const canRenderFogToFloat = (gl: WebGL2RenderingContext): boolean => {
    if (!gl.getExtension('EXT_color_buffer_float')) return false;
    const tex = gl.createTexture();
    const fb = gl.createFramebuffer();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, 1, 1, 0, gl.RGBA, gl.HALF_FLOAT, null);
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    const ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.bindTexture(gl.TEXTURE_2D, null);
    gl.deleteFramebuffer(fb);
    gl.deleteTexture(tex);
    // 有的驱动报了 EXT_color_buffer_float 却拼不成 RGBA16F 的帧缓冲：退回主画面自己算雾
    if (!ok) console.warn('[Nebbia] fog prepass framebuffer incomplete, computing the fog in the main pass');
    return ok;
};

/** 提交六个程序的编译，`poll` 问编好没有。 */
export class NebbiaProgramBuild {
    readonly programs: NebbiaPrograms;
    private readonly parallel: ParallelCompile | null;
    private done = false;

    constructor(private readonly gl: WebGL2RenderingContext, fogToFloat: boolean, scene: NebbiaWindowScene = 'night', glass: NebbiaGlass = 'rain') {
        this.parallel = gl.getExtension('KHR_parallel_shader_compile') as ParallelCompile | null;
        const vs = compileShader(gl, gl.VERTEX_SHADER, NEBBIA_VS);
        const frag = (src: string) => compileShader(gl, gl.FRAGMENT_SHADER, src);
        const shaders = nebbiaSceneShaders(scene, glass);
        this.programs = {
            fog: fogToFloat ? startProgram(gl, vs, frag(shaders.fog), { aPos: 0 }) : null,
            main: startProgram(gl, vs, frag(fogToFloat ? shaders.main : shaders.mainFallback), { aPos: 0 }),
            sprite: startProgram(gl, compileShader(gl, gl.VERTEX_SHADER, NEBBIA_SPRITE_VS), frag(NEBBIA_SPRITE_FS), { aCorner: 0, aRect: 1, aParam: 2 }),
            mask: startProgram(gl, compileShader(gl, gl.VERTEX_SHADER, NEBBIA_MASK_VS), frag(NEBBIA_MASK_FS), { aCorner: 0, aSeg: 1, aParam: 2 }),
            bldFill: scene === 'night' ? startProgram(gl, vs, frag(NEBBIA_BLD_FILL_FS), { aPos: 0 }) : null,
            noise: startProgram(gl, vs, frag(NEBBIA_NOISE_FS), { aPos: 0 }),
            flake: glass === 'snow' ? startProgram(gl, compileShader(gl, gl.VERTEX_SHADER, NEBBIA_FLAKE_VS), frag(NEBBIA_FLAKE_FS), { aCorner: 0, aA: 1, aB: 2, aC: 3 }) : null,
            firefly: glass === 'dew' ? startProgram(gl, compileShader(gl, gl.VERTEX_SHADER, NEBBIA_FIREFLY_VS), frag(NEBBIA_FIREFLY_FS), { aCorner: 0, aA: 1, aB: 2, aC: 3 }) : null,
        };
    }

    /** 都编好了吗：没编好返回 false，不等；编好了查链接结果，失败抛错。 */
    poll(): boolean {
        if (this.done) return true;
        const { gl, parallel } = this;
        const list = [this.programs.fog, this.programs.main, this.programs.sprite, this.programs.mask, this.programs.bldFill, this.programs.noise, this.programs.flake, this.programs.firefly].filter((p): p is WebGLProgram => !!p);
        if (parallel && !list.every(p => gl.getProgramParameter(p, parallel.COMPLETION_STATUS_KHR))) return false;
        for (const p of list) checkLinked(gl, p);
        // 链接好了，着色器对象不再要：删掉（挂在程序上的等程序删了才真正释放）
        for (const p of list) for (const s of gl.getAttachedShaders(p) ?? []) gl.deleteShader(s);
        this.done = true;
        return true;
    }
}
